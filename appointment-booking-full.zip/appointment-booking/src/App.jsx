import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';

function Home() {
  return (
    <div className="p-4 space-y-4">
      <h1 className="text-3xl font-bold">Book Your Appointment</h1>
      <p>Easily schedule appointments with hospital specialists and access healthcare facilities online.</p>
      <Link to="/appointments">
        <button className="bg-blue-600 text-white px-4 py-2 rounded">Book Now</button>
      </Link>
    </div>
  );
}

function Appointments() {
  const doctors = ["Dr. Smith - Cardiology", "Dr. Ayesha - Pediatrics", "Dr. Khan - Neurology"];
  const [name, setName] = useState("");
  const [doctor, setDoctor] = useState("");

  const handleBook = async () => {
    if (!name || !doctor) return alert("Please fill all fields.");
    const res = await fetch("http://localhost:4000/appointments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, doctor }),
    });
    if (res.ok) {
      alert("Appointment booked!");
      setName("");
      setDoctor("");
    } else {
      alert("Failed to book appointment.");
    }
  };

  return (
    <div className="p-4 space-y-6">
      <h2 className="text-2xl font-semibold">Available Doctors</h2>
      <div className="space-y-4">
        <input
          type="text"
          placeholder="Your Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="border p-2 w-full"
        />
        <select
          value={doctor}
          onChange={(e) => setDoctor(e.target.value)}
          className="border p-2 w-full"
        >
          <option value="">Select a doctor</option>
          {doctors.map((doc, idx) => (
            <option key={idx} value={doc}>{doc}</option>
          ))}
        </select>
        <button
          onClick={handleBook}
          className="bg-green-600 text-white px-4 py-2 rounded"
        >
          Book Appointment
        </button>
      </div>
    </div>
  );
}

function Contact() {
  return (
    <div className="p-4 space-y-2">
      <h2 className="text-2xl font-semibold">Contact Us</h2>
      <p>Email: support@hospital.com</p>
      <p>Phone: +123-456-7890</p>
    </div>
  );
}

function App() {
  return (
    <Router>
      <nav className="p-4 space-x-4 bg-gray-100">
        <Link to="/">Home</Link>
        <Link to="/appointments">Appointments</Link>
        <Link to="/contact">Contact</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/appointments" element={<Appointments />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </Router>
  );
}

export default App;
