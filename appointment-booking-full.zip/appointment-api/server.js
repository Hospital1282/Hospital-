const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const PORT = 4000;

app.use(cors());
app.use(bodyParser.json());

let appointments = [];

app.get("/appointments", (req, res) => {
  res.json(appointments);
});

app.post("/appointments", (req, res) => {
  const { name, doctor } = req.body;
  if (name && doctor) {
    const appointment = { id: Date.now(), name, doctor };
    appointments.push(appointment);
    res.status(201).json(appointment);
  } else {
    res.status(400).json({ error: "Name and doctor are required" });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
